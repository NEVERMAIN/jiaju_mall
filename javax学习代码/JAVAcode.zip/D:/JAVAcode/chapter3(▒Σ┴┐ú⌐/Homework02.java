public class Homework02{
	public static void main (String[] args){
		//使用char类型，分别保存 \n \t \r \\ 1 2 3 等字符，并打印输出
		char c1 = '\n' ;  // 换行
		char c2 = '\t' ; // 制表位
		char c3 = '\r' ; // 回正
		char c4 = '\\' ; // 输出\
		char c5 = '1' ; //1
		char c6 = '2' ; //2
		char c7 = '3' ; //3

		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
		System.out.println(c5);
		System.out.println(c6);
		System.out.println(c7);




	}
}