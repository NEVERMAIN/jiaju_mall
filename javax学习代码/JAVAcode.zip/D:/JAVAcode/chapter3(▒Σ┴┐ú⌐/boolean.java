public class boolean{
	public static void main (String[] args){
		//演示判断成绩是否通过的案例
		//定义一个布尔变量
		boolean isPass = false;
		if(isPass == true) {
			System.out.println("考试通过了，恭喜");
		}else {
			System.out.println("考试没有通过，下次努力");
		}
	}
}