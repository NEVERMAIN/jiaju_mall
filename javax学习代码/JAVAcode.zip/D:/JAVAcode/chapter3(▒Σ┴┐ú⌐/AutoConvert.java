public class AutoConvert{
	public static void main (String[] agrs){
		//演示自动类型转换
		int num = 'a';//ok   char->int 
		double d1 = 80;//ok  int ->double
		System.out.println(num);//  a -> 97
		System.out.println(d1);//80.0

	}
}