public class IntDetail{
	public static void main (String[] args){
		int n1 = 1;
		//int n2 = 1L;
		long n3 =  1L;
		System.out.println(" ");
	}
}