public class FloatDetail{
	public static void main (String[] args){
		//java的浮点数常量默认为是double型，声明为float
		//float num1 = 1.1;//错误
		//double num2 = 1.1;对
		float num3 = 1.1F;//对
		double num4 = 1.1f;//对

		//十进制数形式：如：5.12       512.0f
		double num5 = .123;//等价
		System.out.println(num5);
		//科学计数法：如5.12e2  5.12*(10^2)  5.12E-2  5.12/(10^2)
		System.out.println(5.12e2);//512
		System.out.println(5.12E-2);//0.0512
		//通常情况下，应该使用double，更准确。
		double num09 = 2.1234567851;
		float num10 = 2.1234567851F;
		System.out.println(num09);
		System.out.println(num10);
		//浮点数使用陷阱
		double num11 = 2.7;
		double num12 = 8.1/3; //2.7
		System.out.println(num11); 
		System.out.println(num12); //接近2.7的小数
		//tips：当我们对运算结果是小数的进行相等判断时，要小心
		if(num11 == num12)
			System.out.println("相等");
		//应该是以两个数的差值的绝对值，在某个精度范围判断
		//正确的写法
		if (Math.abs(num11 - num12) < 0.000001){

			System.out.println("差值非常小，到我的规定精度，认为相等");
		}
		//通过Java API 来看
			System.out.println(Math.abs(mun11-num12);
		//细节：如果是直接查询得到的小数或者直接赋值的，是可以判断相等

		
	}
}