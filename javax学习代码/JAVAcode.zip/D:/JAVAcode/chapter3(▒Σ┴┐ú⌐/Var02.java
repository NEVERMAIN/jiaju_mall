public class Var02{
	public static void main (String[] args){
		//plus +号的使用
		System.out.println(100+98);//198
		System.out.println("100"+98);//10098
		System.out.println("hello"+100+3);//hello1003
		System.out.println(100+3+"hello");//103hello

	}
}	