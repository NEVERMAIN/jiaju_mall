public class Var01{
	public static void main (String[] args){
		//记录人的信息
		int age = 30;
		double score = 88.9;
		char gender = '男';
		String name = "king";
		//输出信息，快捷键
		System.out.println("人的信息如下：");
		System.out.println(name);
		System.out.println(age);
		System.out.println(score);
		System.out.println(gender);

	}
}