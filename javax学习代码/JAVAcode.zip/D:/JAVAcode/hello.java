


public class hello{
	public static void main(String[] args){
		//args 是如何传入
		//遍历输出
		for(int i = 0;i < args.length;i++){
			System.out.println("第"+(i+1)+"个参数="+args[i]);
		}
	}
}