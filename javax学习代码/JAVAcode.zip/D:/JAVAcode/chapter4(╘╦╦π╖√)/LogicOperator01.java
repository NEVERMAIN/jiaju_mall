//演示逻辑运算的使用
public class LogicOperator01{

	public static void main (String[] args){
		// &&  短路与 和 & 案例演示
		int age = 50;
		if(age > 20 && age < 90){
			System.out.println("ok100");
		}

		// & 逻辑与 使用
		if(age > 20 & age < 90) {
			System.out.println("ok200");
		}

		if(age > 20 & age < 40) {
			System.out.println("ok300");
		}

		//区别 
		int a = 4;
		int b = 9;
		if (a < 1 && ++b < 50) {
			//短路与&&  如果第一个条件为false,后面的条件不在判断，效率更高
			//对于逻辑与&而言， 如果第一个条件为false,后面的条件仍然要判断，效率低
			//开发中 ，基本使用短路与&&；
			System.out.println("ok400");
		}
		System.out.println("a=" + a + "b=" + b); //  4  9







	}
}