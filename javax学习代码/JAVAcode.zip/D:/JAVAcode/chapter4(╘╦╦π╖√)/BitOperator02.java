public class BitOperator02{
	public static void main (String[] args) {

		System.out.println(1>>2);   // 0
		System.out.printtln(1<<2);  // 1*2*2=4
		System.out.printtln(4<<3);  //4*2*2*2=32
		System.out.println(15>>2);  //15/2/2=3




	}
}