//演示关系运算符的使用

public class RelationalOperator{
	public static void main (String[] args) {

		int a = 9;
		int b = 8;
		System.out.println(a > b); // T
		System.out.println(a >= b); //T 
		System.out.println(a <= b); //F
		System.out.println(a < b); //F
		System.out.println(a == b); //F
		System.out.println(a != b); //T
		boolean flag = a > b; //T
		System.out.println("flag=" + flag);

		//关系运算符的结果都是boolean型，也就是要么true,要么是false.
		//关系运算符组成的表达式，称为关系表达式。a>b
		//比较运算符"=="不能误写成"="

		

	}
}