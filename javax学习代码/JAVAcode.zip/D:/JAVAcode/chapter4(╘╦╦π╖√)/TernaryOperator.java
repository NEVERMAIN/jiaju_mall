//三元运算符的使用
public class TernaryOperator{
	public static void main (String[] args){

		
		int a = 10;
		int b = 99;
		//解读
		//1. a>b 为false
		//2.返回b--，先返回b的值，然后再 b-1;
		//3.返回结果是99；
		int result = a > b ? a++ : b--; 
		System.out.println("result=" + result);

		int result1 = a < b ? a++ : b--;
		System.out.println("result1=" + result1);
		System.out.println("a=" + a);
		System.out.println("b=" + b);
		


	}
}