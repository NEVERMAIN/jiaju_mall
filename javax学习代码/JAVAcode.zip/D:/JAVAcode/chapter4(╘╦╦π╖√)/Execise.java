public class Execise{
	public static void main (String[] args) {

		System.out.println(Ob00011111);
		System.out.println(0246);
		System.out.println(0X22D0);

	}
}