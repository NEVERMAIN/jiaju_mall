public class TernaryOperatorDetail{
	public static void main (String[] args){
//表达式1和表达式2 要为可以赋给接收变量的类型（或可以自动转换或者强制转换）
		int a =3;
		int b =8;
		//int c = a > b ? 1.1 : 3.4;   错误double不可以赋给int
		double c = a > b ? a : b+3 ;//可以，满足 int -> double



	}
}