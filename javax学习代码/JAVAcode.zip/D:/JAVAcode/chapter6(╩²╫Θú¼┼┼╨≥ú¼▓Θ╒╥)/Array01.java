
//数组的引出
public class Array01{
	public static void main (String[] args){

		//定义一个数组
		// double[] 表示double类型的数组，数组名 hens

		double[] hens = {3,5,1,3.4,2,50};
		double totalweight =0;
		System.out.println("数组的长度="+ hens.length);
		//遍历数组得到数组的所有元素和。使用for
		for(int i =0 ; i< hens.length ; i++){
			System.out.println("第"+(i+1)+"个元素的值="+hens[i]);
			totalweight += hens[i];
		}
		System.out.println("总体重="+totalweight+"平均体重="+(totalweight/hens.length));



		







	}
}