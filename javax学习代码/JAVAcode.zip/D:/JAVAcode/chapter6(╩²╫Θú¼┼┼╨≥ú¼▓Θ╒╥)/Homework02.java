
public class Homework02{

	public static void main(String[] args){
		//随即生成10个整数（1-100）保存到数组，并倒序打印以及求平均值，
		//求最大值及其下标，并查找里面又没有8
		int[] arr = new int[10];
		for(int i=0;i<arr.length;i++){
			arr[i] = (int)(Math.random()*100) +1;
		}
		System.out.println("===arr的顺序输出===");
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+" ");
		}

		System.out.println("\n======arr的倒序输出====");
		for(int i = arr.length-1;i>=0;i--){
			System.out.print(arr[i]+" ");
		}
		System.out.println();

		int Max = arr[0];
		int MaxIndex = 0;
		int sum =arr[0];
		for(int i=1;i<arr.length;i++){
			sum += arr[i];
			if(Max<arr[i]){
				Max= arr[i];
				MaxIndex = i;
			}
		}
		System.out.println("Max="+ Max+ "MaxIndex="+MaxIndex);
		System.out.println("sum="+ sum);

		int findName = 8;
		int index = -1;
		for(int i=0;i<arr.length;i++){
			if(findName==arr[i]){
				System.out.println("找到了"+findName);
				index = i;
				break;
			}
		}
		if(index==-1){
			System.out.println("没有找到"+findName);
		}















	}
}