
public class ArrayExercise01{
	public static void main (String[] args) {

		char a[] = new char[26];
		System.out.println("输入元素");
		for(int i=0;i<a.length;i++) {//循环26次
			//a 是 char[];,  ,char[i] 是 char;
			a[i] = (char)('A' + i);//'A'+i 是int ,需要强转
		}


		//循环输出
		for(int i =0;i<a.length;i++){
			System.out.println("第"+(i+1)+"个元素="+a[i]);
		} 


	}
}