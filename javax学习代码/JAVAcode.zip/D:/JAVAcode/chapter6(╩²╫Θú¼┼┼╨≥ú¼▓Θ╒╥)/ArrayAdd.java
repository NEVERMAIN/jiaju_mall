import java.util.Scanner;
public class ArrayAdd{

	public static void main (String[] args) {
		//扩容
		//定义一个原始数组
        //增加元素：1.定义一个新的数组。 int[] arrnew = new int[arr.length + 1];
		//2.遍历 arr 数组 ，依次将arr的元素拷贝到arrnew数组
		//3.将 4 赋值 arrnew[arrnew.length -1] = 4;
		//4.将 arr 指向 arrnew ; arr = arrnew; 那么 原来的arr数组将被销毁。

		/*创建一个Scanner可以接收用户输入
		用户什么时候退出不确定 用 do-while + break  来控制。
		*/
		Scanner myScanner = new Scanner(System.in);
		int[] arr = {1,2,3};
		do{
			int[] arrnew = new int[arr.length+1];
			//遍历 arr 数组 ，依次将arr的元素拷贝到arrnew的数组上
			for(int i=0;i<arr.length;i++){
				arrnew[i] = arr[i];
				
			}
			System.out.println("输入你要添加的元素");
			int arrNum = myScanner.nextInt();
			arrnew[arrnew.length-1] = arrNum;
			arr = arrnew;
			System.out.println("=====arr扩容后的元素======");
			for(int i=0;i<arr.length;i++){
				System.out.print(arr[i]+"\t");
			}
			System.out.println("是否继续增加元素  y/n");
			char key = myScanner.next().charAt(0);
			if(key=='n'){
				break;
			}

		}while(true);

		System.out.println("退出添加。。。。");
		
		
		
		





	}
}