public class ArrayExercise02{
	public static void main (String[] args) {
		/*1.定义一个数组
		  2.假定arr[0]是最大值，maxIndex=0;
		  3.从下标1 开始遍历arr，如果max<当前的元素，说明max不是真正的最大值
		  4.就用max = 当前元素；maxIndex= 为当前元素下标；
		  5.当我们遍历这个数组时，max就是最大值，maxIndex为最大值对应下标；


		*/
		int arr[] = {4,-1,9,10,23};
		int max = arr[0];
		int maxIndex=0;
		for(int i=1;i<arr.length;i++){
			if(max < arr[i]) {
				max = arr[i];
				maxIndex = i;
			}
		}
		System.out.println("max=" + max + " " + "maxIndex=" + maxIndex);

		

	}
}
