public class twoDimentionalArray02{

	public static void main(String[] args){
		//动态初始化1
		// int arr[][]= new int[2][3];
		// arr[1][1] = 8;
		// for(int i=0;i<arr.length;i++){
		// 	for(int j=0;j<arr[i].length;j++){
		// 		System.out.print(arr[i][j] + " ");
		// 	}
		// 	System.out.pritnln();
		// }


		//动态初始化2
		// int arr[][];//声明二维数组
		// arr = new int[2][3];//再开空间



		//动态初始化3——列数不确定
		/*一个 有三个一维数组的数组，每个一维数组的元素是不一样的  数组

		*/
		// int[][] arr = new int[3][]; //创建 二维数组,共有3个一维数组，但每一个
		// //                           一维数组是没有空间 
		// for (int i =0;i< arr.length;i++){//遍历arr每个一维数组
		// 	//给每一个一维数组开空间 new
		// 	//如果没有给一维数组new ,那么 arr[i] 就是 null;
		// 	arr[i] = new int[i + 1];

		// 	//遍历一维数组，并给一维数组赋值
		// 	for(int j =0;j<arr[i].length;j++){
		// 		arr[i][j] = i + 1;
		// 	}

		// }

		// //遍历输出
		// for(int i = 0;i < arr.length;i++){
		// 	for(int j=0;j<arr[i].length;j++){
		// 		System.out.print(arr[i][j]+ " ");
		// 	}
		// 	System.out.println();
		// }


		//静态初始化
		//int[][] arr = {{1,1,1},{2,2,2},{3,3,3}};
		//int[][] arr = {{1,1,1},{2,2,2},100};//错误 不能把基本数据类型赋给二维数组 
		//  每一个元素是一维数组。。   不能把int -> int[]
		                                       
 









	}
}