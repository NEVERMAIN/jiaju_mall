public class Homework01{

	public static void main(String[] args){
		// /*已知有一个升序的数组，要求插入一个元素后，该数组的顺序依然是升序，
		// 比如：[10,12,45,90],添加23后，数组为[10,12,23,45,90]
		// 扩容+定位
		// */


		// int[] arr = {10,12,45,90};
		// int[]arrnew = new int[5];
		// for(int i=0;i<arr.length;i++){
		// 	arrnew[i] = arr[i];
		// }
		// arrnew[4] = 23; 
		// arr= arrnew;
		// int temp = 0;
		// for(int i=0;i<arr.length-1;i++){
		// 	for(int j=0;j<arr.length-1-i;j++){
		// 		if( arr[j] > arr[j+1] ){
		// 			temp = arr[j+1];
		// 			arr[j+1] = arr[j];
		// 			arr[j] = temp; 
		// 		}


		// 	}
		// }
		// //输出arr[i]
		// for(int i=0;i<arr.length;i++){
		// 	System.out.print(arr[i]+" ");
		// }


/*思路：本质是数组扩容+定位
1.我i们先确定 添加数应该插入到哪个索引
2.然后扩容
*/
		//先定义原数组
		int[] arr = {10,12,45,90};
		int insertNum = 23;
		int index = -1; //index就是要插的位置

//遍历 arr数组，
//如果发现insertNum <= arr[i], 说明 i 就是要插入的位置，使用index保留i 
//如果遍历完后，没有发现 insertNum <= arr[i],说明 index = arr.length
//即添加到arr的最后
		for(int i=0;i<arr.length;i++){
			if(insertNum <= arr[i]){
				index = i;
				break; //找到位置后，就退出
			}
		}
		if(index==-1){
			index=arr.length;
		}
		System.out.println("index="+index);

		//扩容
		//先创建一个新的数组，大小为 arr.length+1
		//把arr的元素拷贝到arrNew,并且要跳过 index位置
		int[] arrNew  = new int[arr.length+1];
		for(int i=0,j=0;i<arrNew.length;i++){
			if(index != i){//把arr的元素拷贝到arrNew
				arrNew[i] = arr[j];
				j++; 
			}else{//i这个位置就是要插入的数
				arrNew[i] = insertNum;
			}
		}
		//让 arr 指向 arrNew ,原来的数组被销毁
		arr = arrNew;
		System.out.print("======arr的元素情况====");
		for(int i =0;i<arr.length;i++){
			System.out.print(arr[i]+" ");
		}


	}
}