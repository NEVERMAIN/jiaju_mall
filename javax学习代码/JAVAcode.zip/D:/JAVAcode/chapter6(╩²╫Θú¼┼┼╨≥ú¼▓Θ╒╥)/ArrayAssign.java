public class ArrayAssign{
	public static void main (String[] args) {

		//基本数据据类型赋值
		int n1 = 10;
		int n2 = n1;
		n2 = 80;
		System.out.println("n1="+10);
		System.out.println("n2="+80);
		//数组是引用传递，，赋的值是地址
	 	int[] arr1 = {1,2,3};
	 	int[] arr2 = arr1; //把arr1赋值给arr2
	 	arr2[0] = 10;
	 	System.out.println("======arr1元素====");
	 	for(int i=0;i<arr1.length;i++){
	 		System.out.println(arr1[i]);
	 	}





	}
}