public class ArrayReverse{

	public static void main (String[] args) {
	
	// int[] arr = {11,22,33,44,55,66};
	// //规律：1.把arr[0]和arr[5]交换
	// //2.把arr[1]和arr[4]交换
	// //3.把arr[2]和arr[3]交换
	// //4.一共要交换3次  arr.length / 2
	// //5.每次交换时，对应下标arr[i]和arr[arr.length - 1 - i]


	// int temp = 0;
	// int len = arr.length;
	// for(int i = 0 ; i < (len / 2) ;i++){
	// 	temp = arr[arr.length-1-i];
	// 	arr[arr.length-1-i] = arr[i];
	// 	arr[i] = temp;
	// }
	// System.out.println("===反转后的数组===");

	// for (int i = 0;i< len;i++) {
	// 	System.out.println(arr[i] + " \t");
	// }


	//逆序赋值法
	int arr[] = {11,22,33,44,55,66};
	//先创建一个数组 arr2,大小为arr.length
	//逆序遍历 arr,将每个元素拷贝到 arr2 的元素中
	int[] arr2 = new int[arr.length];
	for(int i = arr.length - 1,int j=0;i>=0;i--,j++){
		arr2[j] = arr[i];
	}
	//让 arr 指向arr2的数据空间,此时 arr原来的数据空间就没有变量引用了，
	//会被当成垃圾，销毁
	arr = arr2;
	System.out.println("=====arr的数据元素===");
	
	for(int i=0;i,arr.length;i++){
		System.out.println(arr[i] +"\t");
	}




	}
}