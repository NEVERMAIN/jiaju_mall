import java.util.Scanner;
public class ArrayReduse{

	public static void main (String[] args) {
		Scanner myScanner = new Scanner(System.in);
		int[] arr = {1,2,3,4,5};
		do{
			

			int[] arrnew = new int[arr.length - 1];
			for(int i=0; i<arrnew.length; i++){
				arrnew[i] = arr[i];
				arr = arrnew;
			}
			System.out.println("====arr剩下的元素=====");
			for(int i=0; i<arr.length; i++){
				System.out.print(arr[i]+"\t");
			}

			System.out.println("是否删除元素  y/n");
			char key = myScanner.next().charAt(0);
			if(key=='n'){
				break;
			}
			if(arr.length==1){
				System.out.println("只剩下最后一个元素了，请退出");
			}

		}while(true);

		System.out.println("退出删除程序.......");





	}
}