import java.util.Scanner;
public class SeqSearch{

	public static void main(String[] args){
		//定义一个字符串数组
		String[] names= {"金毛狮王","白眉鹰王","青翼蝠王","紫衫龙王"};
		Scanner myScanner = new Scanner(System.in);

		System.out.println("请输入名字");
		String findName = myScanner.next();
		
		System.out.println(findName);
		//遍历数组，逐一比较，如果有，提示信息，并退出。
		//编程思想： 设置索引

		int index = -1;
		for(int i=0; i < names.length; i++){
			//比较 字符串比较 equals
			if(findName.equals(names[i])) {
				System.out.println("找到了"+findName);
				System.out.println("下标为="+i);
				//把 i 保存到index 上
				index = i;
				break;//退出
			}

		}
		if(index == -1) {
			System.out.println("sorry，没有找到"+findName);
		}


	}
}