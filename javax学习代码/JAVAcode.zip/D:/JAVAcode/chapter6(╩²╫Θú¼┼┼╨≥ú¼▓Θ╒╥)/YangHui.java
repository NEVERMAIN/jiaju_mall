public class YangHui{

	public static void main(String[] args){
		//二维数组的经典应用---杨辉三角
		/*
		1
		1 1
		1 2 1
		1 3 3 1
		1 4 6 4 1
		.。。。。。	
	
		*/
		int [][] arr = new int[10][];
		for(int i=0;i<arr.length;i++){
           //给每一个一维数组开辟空间
			arr[i] = new int[i+1];
           //给每个一维数组赋值
			for(int j =0;j<arr[i].length;j++){
				//每一行的第一个元素和最后一个元素为1；  特殊情况用if
				if(j==0 || j==arr[i].length-1){
					arr[i][j] = 1;
				}else{//中间的元素
					arr[i][j]= arr[i-1][j]+arr[i-1][j-1];
				}
	 
			}
		}

		//输出
		for(int i=0;i<arr.length;i++){
			for(int j =0;j<arr[i].length;j++){
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}






	}
}