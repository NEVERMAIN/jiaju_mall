public class Homework03{

	public static void main(String[] args){
		/*冒泡排序，从小到大
		从大到小
		int[] arr = {20,-1,89,2,890,7}
		*/
		int temp = 0;//辅助交换
		int[] arr = {20,-1,89,2,890,7};
		for(int i=0;i<arr.length-1;i++){
			for(int j=0;j<arr.length-1-i;j++){
				if(arr[j]>arr[j+1]){
					temp = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = temp;
				}
			}
		}
		//输出
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i] + " ");
		}



/*
		int temp = 0;//辅助交换
		int[] arr = {20,-1,89,2,890,7};
		for(int i=0;i<arr.length-1;i++){
			for(int j=0;j<arr.length-1-i;j++){
				if(arr[j]<arr[j+1]){
					temp = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = temp;
				}
			}
		}
		//输出
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i] + " ");
		}


*/


	}
}