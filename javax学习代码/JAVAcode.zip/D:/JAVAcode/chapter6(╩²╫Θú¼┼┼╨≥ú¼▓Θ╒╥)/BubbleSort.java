public class BubbleSort{
	public static void main(String[] args){
		/*冒泡排序
		化繁为简
		将多轮排序用外层循环包起来。
		先死后活


		*/




		int[] arr = {24,69,80,57,13};
		int temp =0; //辅助交换变量
		//将多轮排序用外层循环包起来。
		for(int i=0;i < arr.length -1; i++){//多层循环
			for(int j=0;j < arr.length -1 - i; j++){//4次比较  ->4->3->2->1
				//如果前面的数>后面的数，就交换
				if(arr[j] > arr[j + 1]) {
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		
			System.out.println("\n==第"+(i+1)+"轮===");
			for(int j=0;j< arr.length;j++) {
				System.out.print(arr[j] + "\t");
			}
			
		}

		







	}
}