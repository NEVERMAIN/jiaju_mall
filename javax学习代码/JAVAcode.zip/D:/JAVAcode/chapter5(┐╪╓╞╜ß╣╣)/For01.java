
public class For01{
	public static void main (String[] args) {
		for (int i =1 ; i<=10 ; i++){
			
			System.out.println("你好，韩顺平教育");
		}	
	}
}