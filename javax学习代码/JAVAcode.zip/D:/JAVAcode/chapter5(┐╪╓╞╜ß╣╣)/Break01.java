public class Break{
	public static void main (String[] args){

		//细节1.break语句出现在多层嵌套时，可以通过标签指明要终止的是哪一层
		//      语句块。
		//细节2.标签的使用
		//     lable1:
		//		lable2:
		//		lable3:
		//实际开发中，尽量不要用标签
		//如果没有标签，等价于跳出最近的循环
		lable1:
		for(int j=0;j<4;j++){
		lable2:
			for(int i=0;i<10;i++){
				if(i==2){
					break lable1;
				}
			}System.out.println("i="+ i);

		}


	}
}