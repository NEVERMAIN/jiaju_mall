import java.util.Scanner;
public class Homework04{
	public static void main(String[] args){
		//1.创建Scanner对象
		// Scanner myScanner = new Scanner(System.in);
		// System.out.println("请输入a-e");
		// char c1 = myScanner.next().charAt(0);
		// switch(c1) {
		// 	case 'a' :
		// 		System.out.println("A");
		// 		break;
		// 	case 'b' :
		// 		System.out.println("B");
		// 		break;
		// 	case 'c' :
		// 		System.out.println("C");
		// 		break;
		// 	case 'd' :
		// 		System.out.println("D");
		// 		break;
		// 	case 'e' :
		// 		System.out.println("E"); 
		// 		break;
		// 	default :
		// 		System.out.println("请输入其他的");


           	//对成绩大于60分，输入"合格"。低于60，输入“不合格”。
			//思路：1.成绩在【60.100】，(int)(成绩/60)=1；
			//	    2。成绩在【0，60）  (int)(成绩/60)=0；

			double score = 88.5;
			if(score >=0 && score <= 100) {
			switch((int)(score/60)){
				case 1 :
					System.out.println("合格");
					break;
				case 0 :
					System.out.println("不合格");
					break;
			}
			} else{
				System.out.println("请输入的成绩在0-100");
			}

			








		}
	} 
