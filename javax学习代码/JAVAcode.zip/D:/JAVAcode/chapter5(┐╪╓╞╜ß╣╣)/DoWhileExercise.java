import java.util.Scanner;
public class DoWhileExercise{
	public static void main (String[] args){

		// int i = 1;
		// int sum = 0;
		// int count =0
		// do{
		// 	if(i % 5 == 0 && i % 3 != 0){
		// 	System.out.println(i);
		//  count++;
		// }
		// 	i++;
		// 	sum += i;
		//  
		// } while(i<=200);
		// System.out.println("sum="+sum);
		// System.out.println("count="+count);


		/*化繁为简



		*/

		Scanner myScanner = new Scanner(System.in);
		char answer = ' ';

		do{

			System.out.println("使用五连鞭");
			System.out.println("还钱吗,你的选择是？ y/n");
			answer = myScanner.next().charAt(0);
			System.out.println("他的回答是" + answer);
			
		}while(answer != 'y');

		System.out.println("早这样不就行了嘛");
		System.out.println("还钱了，回家");;





	}
}