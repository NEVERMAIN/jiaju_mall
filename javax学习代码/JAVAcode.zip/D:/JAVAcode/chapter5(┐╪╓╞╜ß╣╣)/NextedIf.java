import java.util.Scanner;
public class NextedIf{
	public static void main (String[] args){

		/*  1.创建Scanner对象，接收用户输入
			2.接收 成绩保存到double score 
			3.使用if-else 判断 如果初赛成绩大于8.0 进入初赛，否则提示淘汰
			4.如果进入决赛 ，在接受char gender ，使用if-else 输出信息
			5.代码实现 */
		Scanner myScanner = new Scanner(System.in);
		System.out.println("请输入初赛成绩");
		double score = myScanner.nextDouble();

		if(score > 8.0)
		{
			System.out.println("请输入性别");
			char gender = myScanner.next().charAt(0);

			if( gender == '男') 
			{
				System.out.println("进入男子组");
			} else if (gender == '女') 
			{
				System.out.println("进入女子组");
			} else 
			{
				System.out.println("你的性别有误，不能参加");
			}
		} else 
		{
			System.out.println("sorry,你被淘汰了~");
		}



	}
}