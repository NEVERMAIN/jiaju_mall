public class ForDetail{
	public static void main (String[] args) {
		//细节1.
		// for (int i ; i<=10 ;i++ ){
		// 	System.out.println("你好");
		// }
		// System.out.println(i)  错误
		//i 的范围只有在for循环中

		//补充
		// for (;;){  无限循环
		// 	System.out.println("ok");
		// }

		//循环初始值可以有多条初始化语句，但要求类型一样，并且中间用逗号隔开，
		//循环变量迭代也可以有多条变量迭代语句，中间用逗号隔开
		int count = 3;
		for (int i=0,int j=0;i<count;i++,j+=2){
			System.out.println("i=" + i  "j" + j);
		}


	}
}