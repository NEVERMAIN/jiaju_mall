public class ForExercise02{
	public static void main (String[] args) {
		//化繁为简
		//先输出0--5
		//后面的+是 5-i
		//先死后活
		//1. 5替换成变量n
		//2. 

		for (int i=0;i<=5;i++){
			System.out.println(i+ "+" (5-i) + "=5");
		}









	}
}
