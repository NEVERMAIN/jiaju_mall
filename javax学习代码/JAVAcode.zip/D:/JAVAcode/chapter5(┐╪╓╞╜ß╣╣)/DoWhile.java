
public class DoWhile{
	public static void main (String[] args){

		int i = 1;
		do {
			//循环执行语句
			System.out.println("你好" + i);
			//循环变量迭代
			i++；

		}while(i <= 10);

		System.out.println("退出do  while 继续执行");
	}
}