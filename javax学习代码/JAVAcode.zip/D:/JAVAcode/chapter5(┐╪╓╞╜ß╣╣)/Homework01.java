public class Homework01{
	public static void main (String[] args) {
		//思路分析：
		//1.定义double money 保存 100000
		//2.三种情况：money > 50000   money < 50000  money < 1000
		//3.使用多分支 if-else if - else 
		//4. while + break [money < 1000],同时使用一个变量保存通关次数

		double money = 100000;
		int count = 0;//累计过的路口
		while(true){//无限循环
			if(money>50000){//过路口
				money *= 0.95;//过完路口还剩多少钱
				count++;
			}else if(money>=1000){
				money -= 1000;
				count++;
			}else {//钱不够了
				break;
			}
		}
		System.out.println(100000+"可以过"+ count +"个路口" );





	}
}