import java.util.Scanner;
public class MulForExercise01{
	public static void main (String[] args){

		 Scanner myScanner = new Scanner(System.in);
		 System.out.println("请输入你的成绩");
		 int score = 0;
		 int toltalscore = 0;
		 int passnum=0;
		 
		 for(int count=1;count<=3;count++){
		 	for (int num =1;num<=5;num++){
				System.out.println(count"班的第"+ num + "个学生");
		 		double grade = myScanner.nextDouble();{
		 			if(grade>==60){
		 				passnum++;
		 			}
		 		}
		 		score += grade;

		 	}
		 	System.out.println("班级的总分"+score+
		 		"每个班的平均分=" + score/5.0);
		 	totalscore += score; 
		 }
		 System.out.println("三个班的总分"+totalscore
		 	+"三个班平均分=" + totalscore/3.0);
		 System.out.println("及格的人数为" + passnum);



		











	} 

}