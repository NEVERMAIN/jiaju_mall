import java.util.Scanner;
public class MulForExercise02{
	public static void main (String[] args){

		//九九乘法表
		/*先输出第一行
		同一行输出多个





		*/

		for (int i=1;i<=9;i++){

			for(int j=1;j<=i;j++) {
				System.out.print(j + "*" + i + "=" + (i*j));
			}
			System.out.print('\n');

			

		}





	}
}