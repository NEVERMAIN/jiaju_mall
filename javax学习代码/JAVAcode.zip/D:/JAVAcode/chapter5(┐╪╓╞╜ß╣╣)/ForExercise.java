public class ForExercise{
	public static void main (String[] args) {

		//打印1-100之间所有是9的倍数的整数，
		//1.化繁为简：即将复杂的需求，拆解成简单的需求，逐步完成
		/*完成1-100的值
		  在输出的过程中，进行过滤，只输出九的倍数， i%9 == 0
		  统计个数 定义一个变量 int count = 0;当条件满足， count++；
		  总和，定义一个变量 int sum =0;当条件满足时累计 sum += i;
		*/

		//2.先死后活：先考虑固定值，然后转成可以灵活变化的值
			/*为了适应更好的需求，把范围开始的值和结束的值，做成变量 int start ;int end
				还可以更进一步，9的倍速也做成变量 int t = 9;
			*/



		int count =0;
		int sum = 0; 
		for (int i=1;i<=100;i++){
			if(i % 9 == 0){
				System.out.pritnln("i=" + i);
				count++;
				sum += i;
			}
		}
		System.out.pritnln("count =" + count "sum =" + sum);






	}
}