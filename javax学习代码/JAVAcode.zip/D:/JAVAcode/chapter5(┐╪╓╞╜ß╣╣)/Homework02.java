import java.util.Scanner;
public class Homework02{
	public static void main (String[] args) {
//作业2
	    // Scanner myScanner = new Scanner(System.in);
		// System.out.println("请输入一个整数");
		// int num = myScanner.nextInt();
		// if(num>0){
		// 	System.out.println("大于0"+num);
		// } else if(num<0){
		// 	System.out.println("小于0"+ num);
		// }else if(num == 0){
		// 	System.out.println("等于0"+ num);
		// }
//作业3

		// Scanner myScanner = new Scanner(System.in);
		// System.out.println("输入年份");
		// int year = myScanner.nextInt();
		// if(year%4==0){
		// 	System.out.println(year+"是闰年");
		// }else {
		// 	System.out.println(year+"不是闰年");
		// }

//作业4.
		/*思路分析：
		1.int n = 153;
		2先得到n的百位，十位，个位的数字，用if判断他们的立方和
		3n的百位=n / 100
		4n的十位= n%100 /10
		5n的个位 = n%10
		6判断即可


		// Scanner myScanner = new Scanner(System.in);
		// System.out.println("输入一个三位数");//153
		// int num = myScanner.nextInt();
		// int num1 = (num%10);
		// System.out.println(num1);//3
		// int num2 = ((num/10)%10);
		// System.out.println(num2);//5
		// int num3 = (num/10/10);
		// System.out.println(num3);//1
		// if(num == (num1*num1*num1) + (num2*num2*num2) + (num3*num3*num3) ){
		// 	System.out.println("这个数是水仙花数");
		// }else{
		// 	System.out.println("这个数不是水仙花数");
		// }








	}
}