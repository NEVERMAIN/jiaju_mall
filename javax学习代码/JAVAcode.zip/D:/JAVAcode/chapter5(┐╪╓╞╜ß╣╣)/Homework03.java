import java.util.Scanner;
public class Homework03{
	public static void main (String[] args) {
//作业6	
/*思路分析：1.输出1-100的所有数
2.然后过滤 输出不能被5整除的数  i % 5 ！= 0
3.每5个一行   使用计数器count统计输出个数  count % 5 ==0
4.输出一个数，输出一个换行*/



		// int count=0;
		// for(int i =1;i<=100;i++) {
		// 	if( i % 5 != 0 ){
		// 		System.out.print(i + "\t");
		// 		count++;
		// 		if(count%5==0){
		// 			System.out.print('\n');
		// 		}
		// 	}
		// }

//作业9
		/*思路分析1.一共有100项相加
		2.每一项的数字在逐渐增加
		3.很像一个双层循环
		i可以表示第几项，同时也是当前项的最后一个数
		4.使用 sum 进行累计即可

*/
		// int sum =0;
		// for(int i =1;i<= 100;i++){
		// 	for(int j=1;j<=i;j++){
		// 		sum += j;
		// 	}
		// }
		// System.out.println("sum =" + sum );


/*
		 int num = 0;
		 int sum = 0;
		 for (int i =1;i<=100;i++){
		 	num += i;
		 	sum += num;
		 }
		 System.out.println(sum);

*/		 
/*
//作业8
思路分析：1.1-1/2+1/3-1/4.。。。。。。1/100 = （1/1）- (1/2)+ (1/3) 
规律：一共100个数，分子为1，分母1-100
     分子为奇数时，前面是+；分母为偶数时，前面是-
     使用for 循环
     把结果放到double sum
     隐藏的陷阱：公式的分子1要写成1.0才能得到精确值
     	double sum = 0;
     	for(int i =1;i<=100;i++) {
			if(i % 2 != 0){
				sum += 1.0/i;
			}else {
				sum -= 1.0/i;
			}
     	}
     	System.out.println("sum="+ sum);


*/




//作业7
/*输出小写的a-z以及大写的Z-A
考察a-z编码和for的综合使用
		思路分析：1.'b' = 'a'+ 1   'c' = 'a'+2
		使用for 循环

		for (char c1 = 'a';c1<='z';c1++){
			System.out.print(c1+" ");
		}
		for(char c2 = 'Z';c2 > 'A';c2--){
			System.out.print(c2+" ");
		}


*/



	}
}