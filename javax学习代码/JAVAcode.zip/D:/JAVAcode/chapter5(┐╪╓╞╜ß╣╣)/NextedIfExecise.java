import java.util.Scanner;
public class NextedIfExecise{
	public static void main (String[] args){

		Scanner myScanner = new Scanner(System.in);
		System.out.println("输入月份");
		int month = myScanner.nextInt();

		if (month == 4 || month == 10){
			System.out.println("请输入年纪");
			double age  = myScanner.nextDouble();
			if(age >= 18 && age <= 60){
				System.out.println("60");
			}else if (age < 18){
				System.out.println("30");
			}else if(age > 60) {
				System.out.println("20");
			}
		}else {
			System.out.println("请输入年纪");
			double age1  = myScanner.nextDouble();
			if(age1 >= 18){
				System.out.println("40");
			}else{
				System.out.println("20");
			}

		}





	}
}
