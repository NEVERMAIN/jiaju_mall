/**
 * @author 韩顺平
 * @version 1.0
 */


public class comment{
	public static void main(String[] argc) {
		System.out.println("");
	}
}