//java编写步骤
2.编写Java的源代码
3.javac 编译，得到对应的.class 字节码文件
4.java 运行，本质就是把.class 加载到jvm 运行