public class Homework02{
	public static void main (String[] args) {
		//
		System.out.println("姓名\t性别\t籍贯\t住址\n顺平\t男\t四川\t北京");
	
	}
}