//JDK,JRE,JVM的关系
答：
1.JDK=JRE+java开发工具
2.JRE=JVM+核心类库