public class Homework01{
	public static void main (String[] args) {
		//编写hello.world程序
		System.out.println("Hello,World!");
	
	}
}