public class PropertisesDetail{
	public static void main(String[] args) {

		//创建person对象
		//P1 是对象名（对象引用）
		//new Person() 创建的对象空间（数据），才是真正的对象
		Person p1 = new Person();

		//对象的属性是默认值，遵守数组规则
		System.out.println("\n当前这个人的信息="+p1.name+" "+p1.age+
						" "+ p1.sal+ " "+p1.isPass);

	}
}

class Person{
	//四个属性
	int age;
	String name;
	double sal;
	boolean isPass;

}
