public class OverLoadExercise{

	public static void main(String[] args) {
		Methods a = new Methods();
		System.out.println(a.m(2));
		System.out.println(a.m(2,3));
		System.out.println(a.m("老韩"));

		System.out.println(a.max(2,4));
		System.out.println(a.max(2.2,3.3));
		System.out.println(a.max(1.1,2.2,33.3));







	}
}

class Methods{


	/*
1.编写程序，类 Methods 中定义三个重载方法并调用。方法名为 m。
三个方法分别接收一个 int 参数、两个 int 参数、一个字符串参数。分别执行平方运算并输出结果，
相乘并输出结果，输出字符串信息。在主类的 main ()方法中分别用参数区别调用三个方法

2.定义三个重载方法 max()，第一个方法，返回两个 int 值中的最大值，
第二个方法，返回两个 double 值中的最大值，第三个方法，
返回三个 double 值中的最大值，并分别调用三个方法
   */

	public int m(int n1){
		return ( n1 * n1);
	}

	public int m(int n1,int n2){
		return ( n1 * n2);
	}

	public String m(String str){
		return str;
	}

	public int max(int n1,int n2){
		return n1 > n2 ? n1 : n2;
	}

	public double max(double n1,double n2){
		return n1 > n2 ? n1 : n2;
	}

	public double max(double n1,double n2,double n3){
		//先求出n1和n2
		double max1 = n1>n2?n1 : n2;
		double max2 = max1 >n3? max1: n3;
		return max2;	
	}
	public double max(double n1,double n2,int n3){
		//先求出n1和n2
		double max1 = n1>n2?n1 : n2;
		double max2 = max1 >n3? max1: n3;
		return max2;	
	}


}