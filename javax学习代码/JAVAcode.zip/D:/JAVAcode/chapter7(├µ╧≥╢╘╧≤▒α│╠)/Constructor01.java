public class Constructor01{

	public static void main(String[] args) {

		Person p1 = new Person("smith",80);//使用的是定义的构造器
		
		System.out.println("p1的对象name如下="+p1.name);
		System.out.println("p1的对象age如下="+p1.age);

		Dog dog1 = new Dog();//使用的是默认的无参构造器


	}
}

class Person{
	String name;
	int age;
	//实现一个交互的过程，自己填入对象信息
	public Person(String Pname,int Page){
		System.out.println("Constructor01被调用===完成初始化");
		name = Pname;
		age = Page;
	}
}

class Dog{
	//如果程序员没有定义构造器，系统会自动生成一个默认无参构造器（默认构造器）
	//使用javap反编译

	/*默认构造器
	Dog(){
	
	}
	*/
	//PS:一旦定义了自己的构造器，默认的构造器就被覆盖了，就再也不能被使用了
	//除非显式的定义一下，即 Dog(){};

	public Dog(String dName){

	}

	public Dog(){
		//显示的定义一下 无参构造器
	}

}