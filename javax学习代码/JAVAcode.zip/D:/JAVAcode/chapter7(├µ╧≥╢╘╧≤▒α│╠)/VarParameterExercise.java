public class VarParameterExercise{

	public static void main(String[] args) {
		HspMethod hm = new HspMethod();
		System.out.println(hm.showScore("老韩",100，60，60));
		System.out.println(hm.showScore("milan",100，60，60.70，80));
		System.out.println(hm.showScore("老韩",100，60));
	}
}

class HspMethod{
	public String showScore(String name,double... scores){
		
		int res =0;
		for(int i=0;i<scores.length;i++){
			res += scores[i];

		}
		return name + "成绩总分为=" + res;

	}
}