public class Scope01{

	public static void main(String[] args) {

		


	}
}