public class MiGong{
	public static void main(String[] args) {

		//思路
		//1.先创建迷宫，用二维数组表示  int[][] map = new int[8][7] 
		//2.先规定 map 数组的元素值； 0表示可以走 1表示障碍物
		//3.将最上面的一行和最下面的一行，全部设置为1；
		//4.将最右边的一行和最左边的一行  全部设置为1；
		//5.单独设置障碍物
		int[][] map = new int[8][7];
		for(int j = 0;j<map[0].length;j++){
			map[0][j] = 1;
			map[7][j] = 1;
		}
		
		for(int i=0;i<map.length;i++){
			map[i][0] = 1;
			map[i][6] = 1;	
		}

		map[3][1] = 1;
		map[3][2] = 1;
		//输出地图
		System.out.println("======当前地图的情况====");
		for(int i=0;i<map.length;i++){
			for(int j=0;j<map[i].length;j++){
				System.out.print(map[i][j]+" ");
			}
			System.out.println();
		}

		//使用fandway给老鼠找路
		T t1 = new T();
		t1.findway(map,1,1);
		System.out.println("\n======找路的情况=====");

		for(int i=0;i<map.length;i++){
			for(int j=0;j<map[i].length;j++){
				System.out.print(map[i][j] +" ");
			}
			System.out.println( );
		}



	}
}

class T{
	//使用递归回溯思想解决老鼠出迷宫

	//1.findWay方法就是专门找出迷宫的路径
	//2.如果找到 返回true；否则返回false
	//3. map 就是二维数组，即迷宫
	//4.i,j就是老鼠初始化的位置，初始化的位置为（1，1）
	//5.用递归找路，先规定map数组的各个值的含义
	// 0表示可以走 1表示障碍物，2表示可以走,（测试过了，不用测试了） 3表示走过，但走不通 死路
	//6.当map[6][5] = 2 就说明找到通路，可以退出了，否则继续找
	//7.先搞定老鼠找路的策略， 下->右—>上->左
	public boolean findway(int[][] map,int i ,int j){

		if(map[6][5]==2){
			return true;
		}else{
			if(map[i][j] == 0){//当前这个位置0，说明表示可以走
				//假定可以走通
				map[i][j] = 2;
				//使用找路的策略，来确定该位置是否真的可以走通
				//false 和 true 是给if语句判断用的
				if(findway(map,i+1,j)){      //先走下
					return true;
				}else if(findway(map,i,j+1)){//走右边
					return true;
				}else if(findway(map,i-1,j)){//走上边
					return true;
				}else if(findway(map,i,j-1)){//走左边
					return true;
				}else{ 
					map[i][j] = 3;
					return false;

				}

			}else{//当前位置map[i][j]为1,2,3，
				return false;

			}
		}

	}

}
