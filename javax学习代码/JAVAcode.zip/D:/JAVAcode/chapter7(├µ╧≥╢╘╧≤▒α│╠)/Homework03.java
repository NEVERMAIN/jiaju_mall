 public class Homework03{

	public static void main(String[] args) {
		Employee p1 = new Employee("张元超","男",22,"助理班主任",500);
		Employee p2 = new Employee("仇浩成","男",18);
		Employee p3 = new Employee("程序员",10000);

	}
}

class Employee{
	String name;
	String sex;
	int age;
	String work;
	double slary;

	public Employee(String name,String sex,int age,String work,double slary){
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.work = work;
		this.slary = slary;
		System.out.println("name="+name+"sex="+sex+"age="+age+"work="+work
					+"slary"+slary);

	}

	
	public Employee(String work,double slary){
		this.work = work;
		this.slary = slary;
		System.out.println("work="+work+"slary"+slary);

	}
	
	public Employee(String name,String sex,int age){
		this.name = name;
		this.sex = sex;
		this.age = age;
		System.out.println("name="+name+"sex="+sex+"age="+age);

	}

	public Employee(String name,String sex,int age,String work,double slary){
		this(name,sex,age);//使用到构造器的复用
		this.work = work;
		this.slary = slary;
		System.out.println("name="+name+"sex="+sex+"age="+age+"work="+work
					+"slary"+slary);

	}
}