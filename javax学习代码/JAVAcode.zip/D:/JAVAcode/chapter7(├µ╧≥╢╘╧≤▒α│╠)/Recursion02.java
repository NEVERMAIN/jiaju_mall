public class Recursion02{
	public static void main(String[] args) {

		

	}
}


class 