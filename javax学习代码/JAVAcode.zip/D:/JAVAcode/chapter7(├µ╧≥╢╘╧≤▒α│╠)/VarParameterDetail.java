public class VarParameterDetail{

	public static void main(String[] args) {
		//1.可变参数的实参可以为数组
		int[] arr = {1,2,3};
		T t1 = new T();
		t1.f1(arr);


	}
}

class T{
	public void f1(int... nums){
		System.out.println("长度=" + nums.length);

	}
	//细节2：可变参数可以和普通类型的参数放在一起参数列表，
	//但必须保证可变参数放在最后
	public void f2(String str,double... nums){


	}

	//细节3.一个参数列表中只能出现一个可变参数
	//public void f3(int... nums1,double... nums2)//错误




}
