public class Homework01{

	public static void main(String[] args) {
		//1
		double[] arr = {12,13,45,23.6,78.9,99.9};
		A01 max01 = new A01();
		Double res = max01.max(arr);
		if(res != null){
			System.out.println("arr的最大值="+res);
		}else{
			System.out.println("arr的输入有误，数组不能为null，或者{}");
		}


		//2
		String[] arr01= {"仇浩诚","吴汶隆","陈沛杰","蔡宇杰"};
		A02 a02 = new A02();
		int index = a02.find("陈晓雄",arr01);
		System.out.println("查找的index ="+ index);


		//测试
		Book book01= new Book("java核心卷",120.0);
		book01.info();
		book01.updatePrice();
		book01.info();








	}
}
//编写类A01，定义方法Max,实现求某个double数组的最大值，并返回
//先考虑正常业务逻辑，在考虑代码的健壮性
class A01{
	public Double max(double[] arr){//返回一个类 Double
		//先判断arr是否为null,然后在判断 length 是否为0

		if(arr != null &&  arr.length > 0){
		//保证arr有一个元素
			double max=arr[0];//假定第一个元素就是最大值
			for(int i=1;i<arr.length;i++){
				if(max<arr[i]){
					max = arr[i];
				}
			}
			return max;//double
		}else{
			return null;

		}


	}
}


//编写类A02  定义方法find，实现查找某个字符串是否在数组中的元素查找，并返回索引，
//如果找不到，就返回-1.
//补充健壮性

class A02{
	public int find(String findStrs, String[] strs){
		//直接遍历字符串数组，如果找到，则返回索引
		for(int i = 0;i< strs.length;i++){
			if(findStrs.equals( strs[i] ) ) {
				return i;
			}
		}
		//如果没有，则返回 -1
		return -1;
	}



	
}
//编写类Book，定义方法updatePrice,实现更改某本书的价格，具体：如果价格》150
//就更改为150，如果价格》100，就更改为100，否则不变
/*分析类名
1.类名 Book
2.属性 price , name
3.方法名  updatePrice
4.形参（）
5.提供一个构造器

*/
class Book {
	String name;
	double price;

	public Book(String name,double price) {
		this.name = name;
		this.price = price;
	}

	public void updatePrice() {
		//如果方法中没有局部变量，this.price = price 
		if(this.price > 150) {
			this.price  = 150;
		}else if(this.price >100){
			this.price = 100; 
		}
	}

	//显示书籍的情况
	public void info() {
		System.out.println("书名="+ this.name + "价格=" + this.price);
	}


	
}
