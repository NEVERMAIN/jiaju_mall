public class ThisDdetail{

	public static void main(String[] args) {



	}
}

class T{
	//访问成员方法的语法  this.方法名（参数列表）
	public void f1(){
		System.out.println("f1() 方法..");
	}
	public void f2(){
		System.out.println("f2() 方法.."); 
		//调用本类的 f1
		//第一种方法
		f1();
		//第二种方法
		this.f1();

	}
}
