public class Method03{
	public static void main(String[] args) {

		AA a = new AA();
		int[] res = a.getSumAndSub(1,4);
		for(int i=0;i<res.length;i++){
			System.out.println(res[i]+" ");
		}





	}
}

class AA {
	//1.一个方法最多一个返回值，【思考如何返回多个结果-->返回数组】
	public int[] getSumAndSub(int n1,int n2){

		int[] resArr  = new int[2];
		resArr[0] = n1 + n2;
		resArr[1] = n1 - n2;
		return resArr;  
	}

    //2.返回类型可以是任意类型，包含基本类型和引用类型；
	//3.方法要求返回数据类型，则方法体中最后的执行语句必须是 return+值；
	//  而且要求返回类型必须和return的值类型一致或兼容 
	public double f1{

		double d1 = 1.1;
		int n = 100;
		//return d1;
		return n;// 通过 int -> double

	}
	//4.如果方法是 void 则方法体中可以没有 return 语句；或者只写return(结束语句) 
}