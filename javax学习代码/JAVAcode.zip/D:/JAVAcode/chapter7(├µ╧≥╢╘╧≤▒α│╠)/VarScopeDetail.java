public class VarScopeDetail{

	public static void main(String[] args) {
		Person p1 =new Person();
		p1.say();//当执行say方法时，say方法的局部变量比如name,会被创建，
		//当say执行完后，name的局部变量就被销毁，但是属性（全局变量）仍可以被使用
		p1.hi();

		T t1 = new T();
		t1.text();//第一种跨类访问 对象属性 的方法
		t1.text02(p1);//第二种跨类访问 对象属性 的方法


	}
}

class T{
	public void text(){
		Person p1 = new Person();
		System.out.println(p1.name);//小白
	}
	public void text02(Person p){
		System.out.println(p.name);//小白
	}
}

class Person{
	//细节：属性可以加修饰符(public protected private)
	//      局部变量不能加修饰符
	public int age = 10;

	String name = "小白";
	public void say(){
		//细节：属性和局部变量可以重名，访问时遵循就近原则
		 String name = "jack";
		 System.out.println("say() name="+name);

	}
	public void hi(){
		String address = "北京";
		//String address = "上海"; 错误,重复定义变量
		String name = "hsp"; 
	}
}