 public class Homework02{

	public static void main(String[] args) {

		int[] oldArr = {10,20,30,40};
		 A03 p1 = new A03();
		 int[] newArr = p1.copyArr(oldArr);
		 System.out.println("====newArr的元素=====");
		 for(int i=0;i<newArr.length;i++){
		 	System.out.print(newArr[i] + "\t");
		 }


		 Circle circle = new Circle(2);
		 System.out.println("\n面积="+ circle.area());
		 System.out.println("周长="+ circle.len());

         //测试1
		 Cale cale = new Cale(4,2);
		 System.out.println("和="+cale.sum());
		 System.out.println("差="+cale.minus());
		 System.out.println("乘="+cale.mul());
		 Double divres = cale.div();
		 if(divres != null) {
		 	System.out.println("除="+cale.div());
		 }
		 //测试2
		 

		 Dog dog01 = new Dog();
		 dog01.show();




	

	}
}


class A03{
	//编写类A03，实现数组的复制功能copyArr,输入旧数组，返回一个新数组
    //元素和就数组一样
	public int[] copyArr(int[] oldArr){
		int[] newArr = new int[oldArr.length];
		for(int i=0;i<oldArr.length;i++){
			newArr[i] = oldArr[i];
		}
		return newArr;

	}
}

class Circle{
	//定义一个圆形Circle,定义属性：半径，提供显示圆周长功能的方法，
    //提供显示圆面积的方法//实现和，差。乘，商（要求除数为0的话，要提示）并且创建两个对象，分别测试

	double radius;
	public Circle(double radius){
		this.radius = radius;
	}
	public double area(){//面积
		return Math.PI * radius * radius;
	}

	public double len(){ //周长
		return 2 * Math.PI * radius;
	} 



	
}

class Cale{
	//编程创建一个Cale计算类，在其中定义2个变量表示两个操作数，定义四个方法
     //实现和，差。乘，商（要求除数为0的话，要提示）并且创建两个对象，分别测试
//当我们返回的结果可能没有正确结果时，用包装类Double
	
	double num01;
	double num02;
	public Cale(double num01,double num02){
		this.num01 = num01;
		this.num02 = num02;
		System.out.println("这两个数分别是"+num01+"和"+num02);
	}
	public double sum (){
		return num01 + num02;
	}
	public double minus(){
		return num01 - num02;
	}
	public double mul(){
		return num01 *num02;
	}
	public Double div(){
		if(num02 == 0){
			System.out.println("不能为0");
			return null;
		}
		return num01 / num02;
	}

	
}

class Dog{
	String name = "大华";
	int age = 20;
	String color = "青绿色";

	public void show(){
		System.out.print("name="+name+" "+"age="+age+" "+"color="+color);

	}


}

