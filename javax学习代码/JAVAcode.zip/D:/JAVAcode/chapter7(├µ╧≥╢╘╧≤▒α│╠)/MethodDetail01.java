public class MethodDetail01{
	public static void main(String[] args) {

	A a	= new A();
	a.sayok();
	
	a.m1();





	}
}

class A {
	//同一个类的方法调用：直接调用即可
	public void print(int n){
		System.out.println("print的方法被调用 n="+ n);

	}

	public void sayok(){//sayok调用 print(直接调用)
		print(10);
		System.out.println("print继续执行");
	}

	public void m1(){

	//跨类调用:需要通过对象名调用
	System.out.println("m1()被执行");
    B b	= new B();
    b.hi();
    System.out.println("m1()继续执行");


	}

}

class B{

	public void hi(){
		System.out.println("B类中的 hi 被执行");
	}
}