public class Method02{
	public static void main(String[] args) {
		int[][] arr = {{0,0,1},{1,1,1},{1,1,3}};
		MyTools tool = new MyTools();

		// //遍历数组arr
		// for(int i=0;i<arr.length;i++){
		// 	for(int j =0;j<arr[i].lrngth;j++){
		// 		System.out.print(arr[i][j]+" ");
		// 	}
		// 	System.out.println();

		// }

		//再次遍历arr数组
		//使用方法完成输出
		tool.printArr(arr);
		tool.printArr(arr);
		tool.printArr(arr);






	}
}

class MyTools{
	//方法 接受一个二维数组

	public void printArr(int[][] arr) {
		//对传入的arr数组进行遍历输出
		System.out.println("=========");
		for(int i=0; i<arr.length; i++){
		 	for(int j =0; j<arr[i].length; j++){
				System.out.print(arr[i][j]+" ");
			}
		 	System.out.println();
	    }
	}



}
