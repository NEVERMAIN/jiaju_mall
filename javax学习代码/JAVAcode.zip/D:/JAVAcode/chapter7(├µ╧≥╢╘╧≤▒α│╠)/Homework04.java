public class Homework04{

	public static void main(String[] args) {

		Circle c  = new Circle();
		PastObject p1 = new PastObject();
		p1.printAreas(c,5);



	}	
}

class Circle{
	double radius;
	public double findArea(double radius){
		return (3.14)*radius*radius;
	}
}

class PastObject{
	public void printAreas(Circle c,double times){
		for(int i=1;i<=times;i++) {
			System.out.println("圆的面积=" +c.findArea(i));
		}

	}
}
