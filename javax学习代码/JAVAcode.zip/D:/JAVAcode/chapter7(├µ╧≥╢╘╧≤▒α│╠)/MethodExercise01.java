public class MethodExercise01{
	public static void main(String[] args) {

		AA a = new AA();
		if(a.isOdd(1)){//
			System.out.println("这个数是奇数");
		}else{
			System.out.println("这个数是偶数");

		}

		print p1= new print();
		p1.print01(4,4,'#');





	}
}

 class AA{
 	//思路1.方法的返回类型
 	//    2.方法的名
 	//    3.方法的形参（）
 	//    4.方法体，判断
	public boolean isOdd(int num){
		
		// if(n % 2 != 0){
		// 	return true;
 			
		// }else{
		// 	return false;
		// }

		//return num % 2 != 0 ? true : false;

		return num % 2 != 0;	
 		

	}
}

class print{
	//根据行、列、字符打印 对应行数和列数的字符，
    //比如：行：4，列：4，字符#,则打印相应的效果

    //思路1.方法的返回类型 void
 	//    2.方法的名 print01
 	//    3.方法的形参（int row,int col,char c）
 	//    4.方法体: 循环

	public void print01(int row,int col,char c){

		for(int i=1;i<=row;i++){
			for(int j=1;j<=col;j++){
				System.out.print(c);
			}
			System.out.println();
		}

	}

}
